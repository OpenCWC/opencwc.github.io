Move contents of FolderA to "C:\ProgramData\OpenColorIO\"
Move contents of FolderB to the Adobe After Effects plugin folder